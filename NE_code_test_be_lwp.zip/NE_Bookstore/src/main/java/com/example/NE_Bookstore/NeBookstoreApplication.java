package com.example.NE_Bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeBookstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeBookstoreApplication.class, args);
	}

}
