INSERT INTO BOOKS (title, price, stock_count, limited) VALUES
  ('Fellowship of the book', 5.0, 12, FALSE),
  ('Books and the chamber of books', 10.0, 15, FALSE),
  ('The Return of the Book', 15.0, 8, FALSE),
  ('Limited Collectors Edition', 75.0, 10, TRUE);

 INSERT INTO USERS (username, password) VALUES ('Uncle_Bob_1337' ,'TomCruiseIsUnder170cm');